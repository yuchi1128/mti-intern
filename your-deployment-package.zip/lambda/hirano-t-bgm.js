const express = require('express');
const multer = require('multer'); // ファイルアップロードのためのミドルウェア
const path = require('path');
const app = express();

// アップロードの設定
const storage = multer.diskStorage({
  destination: './public/music/',
  filename: function(req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// BGMアップロードAPI
app.post('/uploadBGM', upload.single('bgm'), (req, res) => {
  const filePath = `/public/music/${req.file.filename}`;
  // ここでデータベースにfilePathを保存する処理を書く
  res.json({ message: 'BGM uploaded successfully', filePath });
});
