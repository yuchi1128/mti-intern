<template>
  <div>
    <div class="ui main container">
      <ul class="ui divided items">
        <li v-for="(item, index) in users" :key="index" class="item">
          <div class="content">
            <h2 class="header">
              {{ item.userId }}
              <span class="ui green label">{{ item.timestamp }}</span>
            </h2>
            <div class="description">{{ item.text }}</div>
            <div v-if="item.category" class="extra">
              <span class="ui label">{{ item.category }}</span>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
// 必要なものはここでインポートする
// @は/srcの同じ意味です
// import something from '@/components/something.vue';

import { baseUrl } from "@/assets/config.js";

const headers = { Authorization: "mtiToken" };

export default {
  name: 'ArticleView',

  components: {
    // 読み込んだコンポーネント名をここに記述する
  },

  data() {
    // Vue.jsで使う変数はここに記述する
    return {
      userId:[],
      category:"",
      text:"",
      timestamp:"",
      start: 0,
      end: 100,
    };
  },

  computed: {
    // 計算した結果を変数として利用したいときはここに記述する
  },

  methods: {
      clearError() {
        this.errorMsg = "";
        this.successMsg = "";
      },
    },

  created: async function () {
    this.isCallingApi = true;

    try {
      const res = await fetch(`${baseUrl}/users`, {
        method: "GET",
        headers,
      });

      if (!res.ok) {
        const errorMessage = await res.text();
        throw new Error(errorMessage || "エラーメッセージがありません");
      }

      const jsonData = await res.json();
      this.users = jsonData.users ?? [];
      this.successMsg = "ユーザー情報の取得に成功しました";
    } catch (e) {
      this.errorMsg = `ユーザー情報の取得に失敗しました: ${e.message}`;
    } finally {
      this.isCallingApi = false;
    }
  },
}
</script>

<style scoped>
/* このコンポーネントだけに適用するCSSはここに記述する */
</style>
