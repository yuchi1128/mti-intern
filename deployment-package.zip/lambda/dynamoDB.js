const AWS = require('aws-sdk');

// DynamoDBクライアントを設定
AWS.config.update({
    region: "ap-northeast-1", // 適切なリージョンを設定
});

const dynamodb = new AWS.DynamoDB();

const params = {
    TableName: "team2_bgm_tracks",
    KeySchema: [
        { AttributeName: "id", KeyType: "HASH" }  // idをパーティションキーに指定
    ],
    AttributeDefinitions: [
        { AttributeName: "id", AttributeType: "S" }  // idは文字列(S)型に指定
    ],
    ProvisionedThroughput: {
        ReadCapacityUnits: 5,
        WriteCapacityUnits: 5
    }
};

// テーブル作成の実行
dynamodb.createTable(params, function(err, data) {
    if (err) {
        console.error("Unable to create table. Error:", JSON.stringify(err, null, 2));
    } else {
        console.log("Created table. Table description:", JSON.stringify(data, null, 2));
    }
});
